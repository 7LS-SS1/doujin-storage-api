/* global crcAdm, ajaxurl */
/**
 * Comic Reader Companion — Admin UI scripts
 *
 * Responsibilities:
 *  - Accordion toggle for Advanced Settings
 *  - Password show/hide for API Key field
 *  - AJAX "Test Connection" button
 *  - Sync form loading-state (disable buttons + spinner)
 */
(function () {
    'use strict';

    /* ── Accordion ────────────────────────────────────────────── */
    document.querySelectorAll('.crc-adm-accordion-toggle').forEach(function (btn) {
        btn.addEventListener('click', function () {
            var acc = btn.closest('.crc-adm-accordion');
            if (acc) acc.classList.toggle('is-open');
        });
    });

    /* ── Password show / hide ─────────────────────────────────── */
    document.querySelectorAll('[data-crc-toggle-pw]').forEach(function (btn) {
        btn.addEventListener('click', function () {
            var target = document.getElementById(btn.dataset.crcTogglePw);
            if (!target) return;
            var show = target.type === 'password';
            target.type        = show ? 'text' : 'password';
            btn.textContent    = show ? '🙈' : '👁';
            btn.setAttribute('aria-label', show ? 'ซ่อน API Key' : 'แสดง API Key');
        });
    });

    var adminAjaxUrl = typeof crcAdm !== 'undefined' && crcAdm.ajaxUrl
        ? crcAdm.ajaxUrl
        : (typeof ajaxurl !== 'undefined' ? ajaxurl : '');

    /* ── AJAX: Test Connection ────────────────────────────────── */
    var testBtn  = document.getElementById('crc-test-btn');
    var resultEl = document.getElementById('crc-test-result');

    if (testBtn && resultEl && typeof crcAdm !== 'undefined' && adminAjaxUrl) {
        testBtn.addEventListener('click', function () {
            var baseUrl = val('crc_api_base_url').replace(/\/$/, '');
            var apiKey  = val('crc_api_key');

            if (!baseUrl || !apiKey) {
                setResult('warn', '⚠', 'กรุณากรอก URL และ API Key ก่อนทดสอบ');
                return;
            }

            testBtn.disabled    = true;
            resultEl.innerHTML  = '<span class="crc-adm-spinner"></span> กำลังทดสอบการเชื่อมต่อ…';

            var body = new URLSearchParams({
                action:   'crc_test_connection',
                nonce:    crcAdm.nonce,
                base_url: baseUrl,
                api_key:  apiKey,
            });

            fetch(adminAjaxUrl, {
                method:  'POST',
                headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
                body:    body.toString(),
            })
            .then(function (r) {
                if (!r.ok) throw new Error('HTTP ' + r.status);
                return r.json();
            })
            .then(function (data) {
                if (data.success) {
                    setResult('ok', '✓', data.data.message || 'เชื่อมต่อสำเร็จ');
                } else {
                    setResult('err', '✗', (data.data && data.data.message) || 'เชื่อมต่อไม่ได้');
                }
            })
            .catch(function () {
                setResult('err', '✗', 'เกิดข้อผิดพลาดในการเชื่อมต่อ กรุณาลองใหม่');
            })
            .finally(function () {
                testBtn.disabled = false;
            });
        });
    }

    function val(id) {
        var el = document.getElementById(id);
        return el ? el.value.trim() : '';
    }

    function setResult(type, icon, msg) {
        var cls = 'crc-adm-badge crc-adm-badge--' +
            (type === 'ok' ? 'ok' : type === 'warn' ? 'warn' : 'err');
        resultEl.innerHTML =
            '<span class="' + cls + '">' + icon + ' ' + esc(msg) + '</span>';
    }

    function esc(str) {
        return String(str)
            .replace(/&/g,  '&amp;')
            .replace(/</g,  '&lt;')
            .replace(/>/g,  '&gt;')
            .replace(/"/g,  '&quot;');
    }

    /* ── Sync form: loading state ─────────────────────────────── */
    var syncForm = document.getElementById('crc-sync-form');
    var syncFeedback = document.getElementById('crc-sync-feedback');

    if (syncForm) {
        var syncBtns = Array.prototype.slice.call(
            syncForm.querySelectorAll('button[value="incremental"], button[value="full"]')
        );

        syncBtns.forEach(function (btn) {
            btn.dataset.originalText = btn.textContent;
            btn.addEventListener('click', function (event) {
                event.preventDefault();
                runSyncAction(btn);
            });
        });
    }

    function runSyncAction(btn) {
        if (!syncForm || !btn || btn.disabled || !adminAjaxUrl) {
            return;
        }

        var nonceEl = syncForm.querySelector('input[name="crc_sync_nonce"]');
        var nonce = nonceEl ? nonceEl.value : '';

        if (!nonce) {
            setSyncFeedback(
                'err',
                'ไม่พบ nonce สำหรับคำสั่ง Sync',
                'ลองรีโหลดหน้า Sync Status แล้วกดปุ่มอีกครั้ง'
            );
            return;
        }

        setSyncButtonsLoading(btn, true);
        setSyncFeedback('warn', 'กำลังเริ่มคำสั่ง Sync…', 'โปรดรอจนกว่าระบบจะตอบกลับ');

        var body = new URLSearchParams({
            action: 'crc_run_sync_action',
            nonce: nonce,
            sync_action: btn.value
        });

        fetch(adminAjaxUrl, {
            method: 'POST',
            headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
            body: body.toString()
        })
        .then(function (response) {
            var contentType = response.headers.get('content-type') || '';
            if (contentType.indexOf('application/json') === -1) {
                return response.text().then(function (text) {
                    throw buildHttpError(
                        response.status,
                        'เซิร์ฟเวอร์ตอบกลับไม่ใช่ JSON',
                        text
                    );
                });
            }

            return response.json().then(function (data) {
                if (!response.ok || !data.success) {
                    throw buildApiError(response.status, data);
                }
                return data;
            });
        })
        .then(function (data) {
            var stats = data.data && data.data.stats ? data.data.stats : null;
            setSyncFeedback(
                'ok',
                data.data && data.data.message
                    ? data.data.message
                    : 'Sync เสร็จสิ้น',
                stats ? formatSyncStats(stats) : 'กำลังรีโหลดข้อมูลล่าสุด…'
            );
            window.setTimeout(function () {
                window.location.reload();
            }, 900);
        })
        .catch(function (error) {
            if (!error || (!error.userMessage && !error.userDetails)) {
                error = buildNetworkError(error);
            }
            setSyncButtonsLoading(btn, false);
            setSyncFeedback(
                'err',
                error.userMessage || 'Sync ไม่สำเร็จ',
                error.userDetails || 'ลองรีโหลดหน้าแล้วกดใหม่อีกครั้ง'
            );
        });
    }

    function setSyncButtonsLoading(activeBtn, isLoading) {
        if (!syncForm) {
            return;
        }

        syncForm.querySelectorAll('button[value="incremental"], button[value="full"]').forEach(function (btn) {
            var originalText = btn.dataset.originalText || btn.textContent;
            btn.disabled = isLoading;
            btn.textContent = isLoading && btn === activeBtn
                ? '⟳ ' + (btn.dataset.loadingText || 'กำลังดำเนินการ…')
                : originalText;
        });
    }

    function setSyncFeedback(type, title, details) {
        if (!syncFeedback) {
            return;
        }

        var noticeClass = type === 'ok'
            ? 'notice-success'
            : type === 'warn'
                ? 'notice-warning'
                : 'notice-error';

        syncFeedback.innerHTML =
            '<div class="notice ' + noticeClass + ' is-dismissible">' +
                '<p><strong>' + esc(title) + '</strong></p>' +
                (details
                    ? '<p class="crc-adm-feedback-detail">' + esc(details) + '</p>'
                    : '') +
            '</div>';
    }

    function formatSyncStats(stats) {
        return [
            'สร้าง: ' + num(stats.created),
            'อัพเดท: ' + num(stats.updated),
            'ข้าม: ' + num(stats.skipped),
            'Error: ' + num(stats.errors)
        ].join(' · ');
    }

    function buildApiError(status, payload) {
        var message = payload && payload.data && payload.data.message
            ? payload.data.message
            : 'Sync ไม่สำเร็จ';

        return {
            userMessage: message,
            userDetails: hintForStatus(status)
        };
    }

    function buildHttpError(status, summary, rawText) {
        var snippet = stripTags(rawText || '').replace(/\s+/g, ' ').trim().slice(0, 180);
        var details = summary;

        if (snippet) {
            details += ': ' + snippet;
        } else {
            details += '. ' + hintForStatus(status);
        }

        return {
            userMessage: status
                ? 'Sync ไม่สำเร็จ (HTTP ' + status + ')'
                : 'Sync ไม่สำเร็จ',
            userDetails: details
        };
    }

    function buildNetworkError(error) {
        var reason = error && error.message ? error.message : 'Network request failed';

        return {
            userMessage: 'ไม่สามารถส่งคำสั่ง Sync ไปที่ admin-ajax.php ได้',
            userDetails: 'อาจถูกบล็อกโดย network, security plugin, WAF หรือ proxy ระหว่างทาง (' + reason + ')'
        };
    }

    function hintForStatus(status) {
        if (status === 401 || status === 403) {
            return 'คำขอถูกปฏิเสธ อาจเกิดจากสิทธิ์ไม่พอหรือปลั๊กอิน security/WAF บล็อก admin-ajax.php';
        }
        if (status === 409) {
            return 'ระบบมองว่ามีงาน Sync อื่นกำลังทำงานอยู่';
        }
        if (status >= 500) {
            return 'เซิร์ฟเวอร์มีข้อผิดพลาดระหว่างรัน Sync ให้ตรวจ wp-content/debug.log หรือ PHP error log เพิ่มเติม';
        }
        return 'ลองรีโหลดหน้าแล้วกดใหม่ หากยังเกิดซ้ำให้ตรวจ response ของ admin-ajax.php ใน Network tab';
    }

    function stripTags(str) {
        return String(str).replace(/<[^>]*>/g, ' ');
    }

    function num(value) {
        return typeof value === 'number' ? value : parseInt(value || 0, 10) || 0;
    }

})();
